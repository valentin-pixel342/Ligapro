---
name: LigaPro Competitions Engine
colors:
  surface: '#0b122b'
  surface-dim: '#0b122b'
  surface-bright: '#323853'
  surface-container-lowest: '#060c25'
  surface-container-low: '#141a33'
  surface-container: '#0A1432'
  surface-container-high: '#222942'
  surface-container-highest: '#2d334e'
  on-surface: '#dde1ff'
  on-surface-variant: '#c2c6d8'
  inverse-surface: '#dde1ff'
  inverse-on-surface: '#292f49'
  outline: '#8c90a1'
  outline-variant: '#424655'
  surface-tint: '#b3c5ff'
  primary: '#b3c5ff'
  on-primary: '#002b75'
  primary-container: '#1e6bff'
  on-primary-container: '#fffeff'
  inverse-primary: '#0054d7'
  secondary: '#ffe5b1'
  on-secondary: '#3f2e00'
  secondary-container: '#fec300'
  on-secondary-container: '#6d5200'
  tertiary: '#59df89'
  on-tertiary: '#00391a'
  tertiary-container: '#008847'
  on-tertiary-container: '#ffffff'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b3c5ff'
  on-primary-fixed: '#001849'
  on-primary-fixed-variant: '#003fa5'
  secondary-fixed: '#ffdf99'
  secondary-fixed-dim: '#f7be00'
  on-secondary-fixed: '#251a00'
  on-secondary-fixed-variant: '#5a4300'
  tertiary-fixed: '#77fca3'
  tertiary-fixed-dim: '#59df89'
  on-tertiary-fixed: '#00210d'
  on-tertiary-fixed-variant: '#005228'
  background: '#0b122b'
  on-background: '#dde1ff'
  surface-variant: '#2d334e'
  surface-card: '#0D1738'
  surface-elevated: '#13214A'
  border-subtle: '#1E2E65'
  border-focus: '#FFC400'
  status-live: '#E5262D'
  status-success: '#00A859'
  status-warning: '#FFC400'
  text-primary: '#FFFFFF'
  text-secondary: '#F0F4FC'
  text-muted: '#A2B4D6'
  on-accent-dark: '#050B24'
  brand-lime-ec: '#DEFF01'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-score:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: 0.01em
  headline-score-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: 0.01em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '400'
    lineHeight: 30px
  body-base:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-bold:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 28px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: 0.02em
  label-badge:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 18px
    letterSpacing: 0.04em
  mono-clock:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2.5rem
  margin-mobile: 1rem
  space-xs: 0.375rem
  space-sm: 0.75rem
  space-md: 1.125rem
  space-lg: 1.5rem
  space-xl: 2.25rem
---

## Brand & Style

The design system establishes a high-performance, institutional, and broadcast-ready design language for national football competitions. It addresses diverse audiences: operational match delegates, federation officials, accredited media, club directors, and supporters requiring real-time match data.

### Aesthetic Foundation
- **Tone:** Technical, authoritative, cinematic, and uncompromisingly accessible.
- **Visual Style:** Modern Sports Corporate & High-Contrast Precision. Deep space midnight layers, razor-sharp status indicators, and luminous high-visibility accents deliver immediate clarity in broadcast studios, press boxes, field-side mobile devices, and screen readers.
- **Accessibility Anchor:** Built to meet and exceed WCAG 2.2 Level AA and AAA specifications. Visual feedback relies on redundant coding (color + iconography + shape + textual labeling) to ensure zero informational loss across all environmental lighting conditions.

## Colors

The color system operates on an official dark mode foundation (`#050B24`), calibrated for deep contrast, reduced eye fatigue in low-light press rooms, and maximum luminance differentiation for tactical data.

### Color Roles & Contrast Targets
- **Primary Action (`#1E6BFF`):** Electric blue for primary interactive elements, active navigation states, and primary match controls. Generates an 8.4:1 contrast ratio against pure white labels.
- **Secondary / Highlight (`#FFC400`):** Warm solar yellow for key match milestones, gold trophies, and active focal rings. Paired exclusively with `#050B24` on buttons and chips to achieve an 11.2:1 contrast ratio (exceeding AAA requirements).
- **Tertiary (`#00A859`):** Triumph green for confirmed registrations, match approvals, qualification zones, and verified status pills.
- **Neutral Canvas (`#050B24` to `#0D1738`):** Deep midnight blue matrix providing background foundation and tiered surface cards.
- **Live / Danger (`#E5262D`):** Crimson red designated strictly for live broadcast timers, direct red cards, severe sanctions, and urgent errors.
- **Text Systems:** `#FFFFFF` and `#F0F4FC` act as primary foreground layers, delivering a 14.5:1 contrast against surface cards (`#0D1738`). Secondary meta text utilizes `#A2B4D6`, ensuring a minimum 7.2:1 contrast ratio.
- **Brand Heritage Accent (`#DEFF01`):** Electric lime reserved for official tournament branding, trophy motifs, and top-tier spotlight graphics.

## Typography

The typography scale utilizes **Plus Jakarta Sans** for headlines, narrative body, tabular sports metrics, and system labels. Its geometric structure, open apertures, and tall x-height preserve legibility under direct sunlight on handheld devices or across noisy stadium monitor feeds.

### Type Rules
- **Base Body Constraint:** The default running body size strictly starts at `18px` with a `1.5` to `1.55` relative line-height multiplier (`28px`), guaranteeing effortless long-form reading for legal regulations, sanctions notices, and live match narratives.
- **Tabular Data:** Scores, player numbers, card timings, and standings statistics rely on tabular lining numerals (`font-variant-numeric: tabular-nums`) to prevent horizontal jitter during rapid real-time updates.
- **Heading Character:** Headings feature tight letter tracking (`-0.01em` to `-0.02em`) with heavy weight definitions (700 and 800) to balance dynamic editorial presence with structural clarity.

## Layout & Spacing

The layout is structured around an adaptive 12-column responsive fluid grid designed for heavy match data, tabular sports indices, and split-screen media views.

### Form Factor Adaptations
- **Desktop (1200px+):** 12-column grid, `margin: 2.5rem` (40px), `gutter: 1.5rem` (24px). Sidebar accommodates competition switchers and access toolbars while center lanes handle multi-game live boards.
- **Tablet (768px - 1199px):** 8-column grid, `margin: 1.5rem` (24px), `gutter: 1.25rem` (20px). Side navigation condenses into a persistent upper sub-bar.
- **Mobile (< 768px):** 4-column fluid grid, `margin: 1rem` (16px), `gutter: 1rem` (16px). Cards stack vertically; complex comparison tables transform into swipeable stacked cards with sticky pinned team columns.

### Spacing Philosophy
Tokens scale along a 6px baseline unit (`0.375rem`), maintaining generous spacing between actionable items to ensure touch targets exceed 48x48px on mobile devices.

## Elevation & Depth

Visual hierarchy uses physical-plane separation built with structured surface tiers, calibrated border contrast, and atmospheric lighting rather than blurry drop shadows that soften legibility on dark modes.

### Structural Depth Architecture
- **Surface Level 0 (Base Canvas):** `#050B24` (background canvas with an optional 180deg linear gradient toward `#0A1F5C` at the page footer).
- **Surface Level 1 (Card Matrix):** `#0D1738`, enclosed by a continuous 1.5px structural border of `#1E2E65`.
- **Surface Level 2 (Floating & Active Controls):** `#13214A` with a distinct border (`#2B3F85`) and subtle edge refraction (`inset 0 1px 0 rgba(255, 255, 255, 0.08)`).
- **Overlays & Drawers (Level 3):** Deep semi-opaque `#08102B` at 96% opacity paired with `backdrop-filter: blur(12px)`.

### Focus Elevation & High-Visibility Outlines
Interactive items strictly forgo default browser rings in favor of an unmistakable focus state: an offset 3px solid border in `#FFC400` with an outer 2px halo of `#050B24`. This guarantees immediate visual localization for keyboard and switch-access users.

## Shapes

The design system implements a soft, engineered shape language (`roundedness: 1`). Corners are gently eased at `0.25rem` (4px) for micro elements, `0.5rem` (8px) for buttons, inputs, and cards, and `0.75rem` (12px) for large competition scoreboards and modals.

This disciplined curvature reinforces an institutional, technical atmosphere. Circular geometries are reserved strictly for team club crests, player avatars, and binary status indicators.

## Components

### 1. Global Accessibility Floating Toolbar
- **Position & Visibility:** Pinned to top-right viewport or accessible via primary skip links (`Tab 1`).
- **Controls:** Contrast toggles (Dark Default, High Contrast AAA, Clean Light), text scale multiplier (`+10%`, `+20%`, `+30%`), and audio narrative synthesizer toggle.
- **Visual:** `#0D1738` surface, 2px border in `#FFC400`, high-contrast iconography.

### 2. Institutional Header & Profile Selector
- **Structure:** Dual-tier layout. Top institutional bar houses the LigaPro crest and global search.
- **Profile Selector Dropdown:** Segmented trigger letting users shift between operational profiles:
  1. *Aficionado / Prensa* (Editorial stats, high media resolution)
  2. *Delegado Club* (Lineup submission, official rosters)
  3. *Oficial / Comisario* (Incident reports, disciplinary signing)
  4. *Dirección de Competiciones* (Schedule locks, table verification)
- Each profile triggers explicit badge color coding and filtered navigation scope.

### 3. Accessible Standings Table (Tabla de Posiciones)
- **Data Attributes:** Fully compliant `<caption>`, explicit `scope="col"` and `scope="row"` headers.
- **Tie-Breaker Visuals (Criterios de Desempate):** Teams level on points are marked with explicit contextual indicators (e.g., small glyph + tooltip text: `[GD]` Goal Difference, `[H2H]` Direct Matchup), preventing reliance on color alone.
- **Form Columns:** Last 5 games represented by multimodal tokens:
  - Win: Green circle (`#00A859`) with checkmark `✓` and text "V"
  - Draw: Neutral square (`#A2B4D6`) with minus `−` and text "E"
  - Loss: Red triangle (`#E5262D`) with cross `✕` and text "D"

### 4. Live Match Tracker (Marcador en Vivo)
- **Scoreboard:** Fixed height scoreboard card showing home/away badges, names, and bold score counter (`#FFFFFF`).
- **Live State Badge:** Pulsing red indicator accompanied by the uppercase label `"EN VIVO"` and the current match minute with tabular font alignment.
- **Accessible Text Commentary:** Chronological feed paired with screen-reader live region (`aria-live="polite"`). Every entry displays the minute, event type icon, player name, and detailed textual description.

### 5. Multimodal Status Badges
- Statuses must never rely solely on color. Every chip combines:
  1. High-contrast fill background.
  2. Explicit vector icon (shield, alert triangle, clock, checkmark).
  3. All-caps legible label (`label-badge`).

### 6. Interactive Controls (Buttons, Inputs, Checkboxes)
- **Primary Button:** Electric Blue (`#1E6BFF`), bold white text, min height 48px, 8px corner radius.
- **Highlight Action Button:** Solar Yellow (`#FFC400`), dark navy text (`#050B24`), min height 48px.
- **Form Fields:** Dark navy container (`#0D1738`), 2px border (`#1E2E65`), 18px body font text, floating label with high-contrast text (`#F0F4FC`). Error states introduce 2px `#E5262D` border with explicit inline text messages and caution icons.
- **Checkboxes & Radios:** Scaled to 24x24px with high-contrast borders and thick inner glyphs.